//
//  ViewController.m
//  DTRollScrollView
//
//  Created by 彭祖鑫 on 16/3/16.
//  Copyright © 2016年 彭祖鑫. All rights reserved.
//

#import "ViewController.h"
#import "DTRollScrollView.h"

@interface ViewController ()<rollScrollViewDelegate>
@property(nonatomic,strong)DTRollScrollView *rollScrollView;
@property(nonatomic,strong)NSArray *dataSouce;//数据源.
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _dataSouce = @[@"1.png",@"2.png",@"3.png"];
    
    _rollScrollView = [[DTRollScrollView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 140)];//初始化轮播图
    
    _rollScrollView.totalCount = [_dataSouce count];//输入轮播图总数
    _rollScrollView.timeInterva = 2;//轮播间隔时间
    _rollScrollView.backgroundColor = [UIColor blackColor];
    _rollScrollView.imageArray = [_dataSouce mutableCopy];//图片数据源数组
    
    _rollScrollView.delegate = self;//协议
#warning 构建图片方法，必须写，并且必须写在赋值之后！
    [_rollScrollView setImage];//构建图片方法，必须写，并且必须写在赋值之后！
    
    [self.view addSubview:self.rollScrollView];
    
    self.view.backgroundColor = [UIColor cyanColor];
    
    
}

-(void)didSelectedImageIndex:(NSInteger)index{
    NSLog(@"%ld",index);
}

@end
