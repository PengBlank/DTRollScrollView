//
//  rollScrollView.m
//  DT-轮播图
//
//  Copyright © 2016年 pzx. All rights reserved.
//
//自定义的scrollView
#import "DTRollScrollView.h"
#import "UIImageView+WebCache.h"
@interface DTRollScrollView ()<UIScrollViewDelegate>

@property (nonatomic,strong) UIScrollView *scrollview;
@property (nonatomic,strong) UIPageControl *pageControl;//页码
@property (nonatomic,strong) NSTimer *timer;//计时器

@end

@implementation DTRollScrollView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        _scrollview = [[UIScrollView alloc]initWithFrame:frame];
        //pageControl设置
        
        _pageControl = [[UIPageControl alloc]initWithFrame:CGRectMake(0, _scrollview.frame.size.height - 20, _scrollview.frame.size.width, 20)];
        _tapGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapGesture:)];
        
        
        //        _tapGesture  = [[UITapGestureRecognizer alloc]init];
        self.HiddenIndicator = NO;
        self.timeInterva = 1;
        
        [self addSubview:_scrollview];
        [self addSubview:self.pageControl];
        [_scrollview addGestureRecognizer:_tapGesture];
//        [self setImage];
    }
    return self;
}
-(void)setImage{
    
    self.pageControl.numberOfPages = self.totalCount;
    //图片的宽
    CGFloat imageW = self.scrollview.frame.size.width;
    //图片高
    CGFloat imageH = self.scrollview.frame.size.height;
    //图片的Y
    CGFloat imageY = 0;
    //图片总数
    
    NSInteger totalCount = self.totalCount;
    
    //    self.imageArray = [[NSMutableArray alloc]init];
    NSLog(@"%ld",totalCount);
    //1.添加x张图片
    for (int i = 0; i < totalCount ; i++) {
        
        UIImageView *imageView = [[UIImageView alloc]init];
        //图片x
        CGFloat imageX = i*imageW;
        //设置frame
        imageView.frame = CGRectMake(imageX, imageY, imageW, imageH);
        //设置图片
#warning 本地图片名字用上面这个，给图片的url在里面处理则用下面的方法即可
        imageView.image = [UIImage imageNamed:self.imageArray[i]];
        
//        [imageView sd_setImageWithURL:[NSURL URLWithString:self.imageArray[i]] placeholderImage:nil];
        self.scrollview.showsHorizontalScrollIndicator = self.HiddenIndicator;
        self.scrollview.showsVerticalScrollIndicator = self.HiddenIndicator;
        [self.scrollview addSubview:imageView];
    }
    //2.设置scrollView的滚动范围
    CGFloat contentW = totalCount * imageW;
    //不允许垂直方向滚动
    self.scrollview.contentSize = CGSizeMake(contentW, 0);
    //3.设置分页
    self.scrollview.pagingEnabled = YES;
    //4.监听scrollview的滚动
    self.scrollview.delegate = self;
    
    
    
    
    [self addTimer];
    
    
    
}
-(void)nextImage{
    
    int page = (int)self.pageControl.currentPage;
    if (page == self.totalCount - 1) {
        page = 0;
    }else{
        
        page++;
        
    }
    //滚动scrollView
    CGFloat x = page * self.scrollview.frame.size.width;
    self.scrollview.contentOffset = CGPointMake(x, 0);
    
}
//scrollView滚动的时候调用
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    //计算页码
    //页码 = (contentoffset.x + scrollView一半宽度)/scrollView宽度
    CGFloat scrollviewW = scrollView.frame.size.width;
    CGFloat x = scrollView.contentOffset.x;
    int page = (x + scrollviewW/2)/ scrollviewW;
    self.pageControl.currentPage = page;
}
//开始拖拽时调用
-(void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    //暂停计时器
    [self removeTimer];
}
-(void)scrollViewWillEndDragging:(UIScrollView *)scrollView withVelocity:(CGPoint)velocity targetContentOffset:(inout CGPoint *)targetContentOffset{
    //开启定时器
    [self addTimer];
}
//开启定时器
-(void)addTimer{

    self.timer = [NSTimer scheduledTimerWithTimeInterval:self.timeInterva target:self selector:@selector(nextImage) userInfo:nil repeats:YES];
    
}
//
/**
 *  关闭定时器
 */
- (void)removeTimer
{
    [self.timer invalidate];
}

-(void)tapGesture:(UITapGestureRecognizer *)sender{
    
    //可以获取不同图片触发不同事件
    [self.delegate  didSelectedImageIndex:self.pageControl.currentPage];
    
}

-(void)setTotalCount:(NSInteger)totalCount
{
    _totalCount = totalCount;
    
}
-(void)setImageArray:(NSMutableArray *)imageArray{
        _imageArray = imageArray;
    
}
-(void)setTimeInterva:(NSInteger)timeInterva{
    _timeInterva = timeInterva;
}
@end
