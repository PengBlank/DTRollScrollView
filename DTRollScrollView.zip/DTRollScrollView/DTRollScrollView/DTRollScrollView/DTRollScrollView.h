//
//  DTRollScrollView.h
//  DTRollScrollView
//
//  Created by 彭祖鑫 on 16/3/16.
//  Copyright © 2016年 彭祖鑫. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol rollScrollViewDelegate <NSObject>


-(void)didSelectedImageIndex:(NSInteger )index;//定义协议

@end
@interface DTRollScrollView : UIView

@property (nonatomic,retain)id<rollScrollViewDelegate> delegate;
@property(nonatomic,assign)BOOL HiddenIndicator;//是否显示指示条(默认为no)
@property(nonatomic,assign) NSInteger totalCount;//图片总数（必须添加）
@property(nonatomic,strong) NSMutableArray *imageArray;//图片数组(必须添加)
@property(nonatomic,assign) NSInteger timeInterva;//间隔时间
@property(nonatomic,strong)UITapGestureRecognizer *tapGesture;//点击事件
/*! @brief
    构建轮播图方法，一定要写在赋值之后!
*/
-(void)setImage;

@end
