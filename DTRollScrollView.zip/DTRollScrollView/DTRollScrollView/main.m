//
//  main.m
//  DTRollScrollView
//
//  Created by 彭祖鑫 on 16/3/16.
//  Copyright © 2016年 彭祖鑫. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
